using System.Security;
using System.Reflection;

[assembly: AssemblyCompany("http://fluentnhibernate.org")]
[assembly: AssemblyProduct("FluentNHibernate")]
[assembly: AssemblyCopyright("Copyright 2008-2011 James Gregory and contributors (Paul Batum, Hudson Akridge et al). All rights reserved.")]
[assembly: AssemblyVersion("1.3.0.0")]

[assembly: AllowPartiallyTrustedCallers]