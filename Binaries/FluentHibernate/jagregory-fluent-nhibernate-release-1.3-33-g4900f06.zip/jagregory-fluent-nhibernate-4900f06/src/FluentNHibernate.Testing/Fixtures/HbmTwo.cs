using System;

namespace FluentNHibernate.Testing.Fixtures
{
    public class HbmTwo
    {
        public virtual int Id { get; set; }
        public virtual string Name { get; set; }
        public virtual DateTime Age { get; set; }
    }
}