using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;

namespace FluentNHibernate.Testing.Fixtures.AutoMappingAlterations
{
    public class DummyAlteration2 : IAutoMappingAlteration
    {
        public void Alter(AutoPersistenceModel model)
        {

        }
    }
}