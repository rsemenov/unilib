using NUnit.Framework;

namespace FluentNHibernate.Testing.FluentInterfaceTests
{
    [TestFixture]
    public class ManyToManySubPartModelGenerationTests : BaseModelFixture
    {
       
    }
}