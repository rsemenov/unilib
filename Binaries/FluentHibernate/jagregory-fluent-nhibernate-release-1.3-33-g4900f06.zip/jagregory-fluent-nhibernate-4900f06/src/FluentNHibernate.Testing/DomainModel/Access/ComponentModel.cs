﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FluentNHibernate.Testing.DomainModel.Access
{
    class ComponentModel
    {
        public string Value { get; private set; }
    }
}
