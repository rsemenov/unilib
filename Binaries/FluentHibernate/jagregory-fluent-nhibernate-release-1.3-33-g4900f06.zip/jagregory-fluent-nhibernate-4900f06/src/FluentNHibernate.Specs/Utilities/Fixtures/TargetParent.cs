namespace FluentNHibernate.Specs.Utilities.Fixtures
{
    public abstract class TargetParent
    {
        private string SuperProperty { get; set; }
    }
}